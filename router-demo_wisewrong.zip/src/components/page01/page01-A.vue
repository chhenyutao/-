<template>
  <h3 class="text-center red">圆白菜不好吃</h3>
</template>
