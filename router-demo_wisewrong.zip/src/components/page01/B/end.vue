<template>
    <div class="text-center red">好了，到此为止，该练歌了</div>
</template>
