<template>
  <div>
    <h2 class="text-center">{{title}}</h2>
  </div>
</template>

<script>
  export default {
    name: '',
    data () {
      return {
        title: '好好学《小半》别闹'
      }
    },
    components: {}
  }
</script>
